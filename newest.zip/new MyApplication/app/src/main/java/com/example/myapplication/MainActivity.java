package com.example.myapplication;

import android.media.Image;
import android.os.Bundle;
import android.telephony.ims.ImsMmTelManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.ImageView;



import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.lang.reflect.Array;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;

import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;


public class MainActivity extends AppCompatActivity {
    private String TAG = "MainActivity";
    private ListView listView;
    private ListView listView2;
    static String[][] codestr = new String[28][2];
    public static void main(String[] args){
        codestr[0][0] = "0";
        codestr[0][1]= "sunny";
        codestr[0][2]= "R.drawable.image1";
        codestr[1][0] = "1";
        codestr[1][1]= "Mainly sunny";
        codestr[1][2]= "R.drawable.image1";
        codestr[2][0] = "2";
        codestr[2][1]= "Partly Cloudy";
        codestr[2][2]= "R.drawable.image2";
        codestr[3][0] = "3";
        codestr[3][1]= "Cloudy";
        codestr[3][2]= "R.drawable.image3";
        codestr[4][0] = "45";
        codestr[4][1]= "Foggy";
        codestr[4][2]= "R.drawable.image8";
        codestr[5][0] = "48";
        codestr[5][1]= "Rime Fog";
        codestr[5][2]= "R.drawable.image8";
        codestr[6][0] = "51";
        codestr[6][1]= "Light Drizzle";
        codestr[6][2]= "R.drawable.image5";
        codestr[7][0] = "53";
        codestr[7][1]= "Drizzle";
        codestr[7][2]= "R.drawable.image5";
        codestr[8][0] = "55";
        codestr[8][1]= "Heavy Drizzle";
        codestr[8][2]= "R.drawable.image5";
        codestr[9][0] = "56";
        codestr[9][1]= "Light Freezing Drizzle";
        codestr[9][2]= "R.drawable.image5";
        codestr[10][0] = "57";
        codestr[10][1]= "Freezing Drizzle";
        codestr[10][2]= "R.drawable.image5";
        codestr[11][0] = "61";
        codestr[11][1]= "Light Rain";
        codestr[11][2]= "R.drawable.image4";
        codestr[12][0] = "63";
        codestr[12][1]= "Rain";
        codestr[12][2]= "R.drawable.image4";
        codestr[13][0] = "65";
        codestr[13][1]= "Heavy Rain";
        codestr[13][2]= "R.drawable.image4";
        codestr[14][0] = "66";
        codestr[14][1]= "Light Freezing Rain";
        codestr[14][2]= "R.drawable.image4";
        codestr[15][0] = "67";
        codestr[15][1]= "Freezing Rain";
        codestr[15][2]= "R.drawable.image4";
        codestr[16][0] = "71";
        codestr[16][1]= "Light Snow";
        codestr[16][2]= "R.drawable.image7";
        codestr[17][0] = "73";
        codestr[17][1]= "Snow";
        codestr[17][2]= "R.drawable.image7";
        codestr[18][0] = "75";
        codestr[18][1]= "Heavy Snow";
        codestr[18][2]= "R.drawable.image7";
        codestr[19][0] = "77";
        codestr[19][1]= "Snow Grains";
        codestr[19][2]= "R.drawable.image7";
        codestr[20][0] = "80";
        codestr[20][1]= "Light Showers";
        codestr[20][2]= "R.drawable.image4";
        codestr[21][0] = "81";
        codestr[21][1]= "Showers";
        codestr[21][2]= "R.drawable.image4";
        codestr[22][0] = "82";
        codestr[22][1]= "Heavy Showers";
        codestr[22][2]= "R.drawable.image4";
        codestr[23][0] = "85";
        codestr[23][1]= "Light Snow Showers";
        codestr[23][2]= "R.drawable.image7";
        codestr[24][0] = "86";
        codestr[24][1]= "Snow Showers";
        codestr[24][2]= "R.drawable.image7";
        codestr[25][0] = "95";
        codestr[25][1]= "Thunderstorm";
        codestr[25][2]= "R.drawable.image6";
        codestr[26][0] = "96";
        codestr[26][1]= "Light Thunderstorm With Hail";
        codestr[26][2]= "R.drawable.image6";
        codestr[27][0] = "99";
        codestr[27][1]= "Thunderstorm With Hail";
        codestr[27][2]= "R.drawable.image6";
    }

    void time_visible() {
        DateTimeFormatter dtf= DateTimeFormatter.ofPattern("yyyy/MM/dd");
        LocalDateTime now= LocalDateTime.now();
        TextView today = (TextView) findViewById(R.id.todate);
        today.setText(dtf.format(now));
        TextView timer = (TextView) findViewById(R.id.timer);
        int hr = new Date().getHours();
        int mn = new Date().getMinutes();
        String minutes;
        String hours;
        String tim = "";
        if (mn<10) {
            minutes = "0"+mn;
        } else {
            minutes = "" + mn;
        }
        if (hr<10) {
            hours = "0"+hr;
        } else {
            hours = ""+hr;
        }
        tim = hours + ":" + minutes;
        timer.setText(tim);
        timer.setVisibility(View.VISIBLE);
        today.setVisibility(View.VISIBLE);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int[] imageID = new int[]{
                R.id.image1,R.id.image2,R.id.image3,R.id.image4,R.id.image5,R.id.image6,R.id.image7
        };
        ImageView[] imageViews= new ImageView[imageID.length];
        for(int k =0; k<8;k++){
            imageViews[k]= (ImageView) findViewById(imageID[k]);
        }
        for(int i=0; i<8;i++){
            HashMap<String, String> weather_code = TemperatureInfo.temperatureList.get(i);
            for (int j=0; j<28; j++){
                if(weather_code.get(TemperatureInfo.DWC)==codestr[j][0]){
                    imageViews[i]= (ImageView) findViewById(imageID[i]);
                    String str = codestr[j][2];
                    int num;
                    num = Integer.parseInt(str);
                    imageViews[i].setImageResource(num);
                }
            }
        }





        TextView timer = (TextView) findViewById(R.id.timer);
        TextView today = (TextView) findViewById(R.id.todate);
        time_visible();
        listView2 = (ListView) findViewById(R.id.listview2);
        JsonHandlerThread jsonHandlerThread2 = new JsonHandlerThread();
        jsonHandlerThread2.start();
        try {
            jsonHandlerThread2.join();
            SimpleAdapter adapter2 = new SimpleAdapter(
                    this,
                    TemperatureInfo.hourlytemperatureList,
                    R.layout.list_view_layout2,
                    new String[]{TemperatureInfo.HT, TemperatureInfo.HTEM},
                    new int[]{R.id.hourly_time, R.id.hourly_tem}
            );

            listView2.setAdapter(adapter2);
            listView2.setOnItemClickListener(
                    new AdapterView.OnItemClickListener() {
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            HashMap<String, String> temperature = TemperatureInfo.hourlytemperatureList.get(position);
                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                            builder.setTitle(temperature.get(TemperatureInfo.HT));
                            builder.setMessage("Temperature" + temperature.get(TemperatureInfo.HTEM));
                            AlertDialog alertDialog = builder.create();
                            alertDialog.show();
                        }
                    }
            );
        } catch (InterruptedException e) {
            Log.e(TAG, "InterruptedException:" + e.getMessage());
        }
        listView = (ListView) findViewById(R.id.listview);
        JsonHandlerThread jsonHandlerThread = new JsonHandlerThread();
        jsonHandlerThread.start();
        try {
            jsonHandlerThread.join();
            SimpleAdapter adapter = new SimpleAdapter(
                    this,
                    TemperatureInfo.temperatureList,
                    R.layout.list_view_layout,
                    new String[]{TemperatureInfo.DTIME,TemperatureInfo.DMAX, TemperatureInfo.DMIN, TemperatureInfo.DWC},
                    new int[]{R.id.daily_time, R.id.daily_max, R.id.daily_min}
            );
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(
                    new AdapterView.OnItemClickListener() {
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            HashMap<String, String> temperature = TemperatureInfo.temperatureList.get(position);
                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                            builder.setTitle(temperature.get(TemperatureInfo.DMAX));
                            builder.setMessage("Temperature" + temperature.get(TemperatureInfo.DMIN));
                            AlertDialog alertDialog = builder.create();
                            alertDialog.show();
                        }
                    }
            );
        } catch (InterruptedException e) {
            Log.e(TAG, "InterruptedException:" + e.getMessage());
        }



        final Button backbutton = findViewById(R.id.backbutton);
        final Button dailybutton = findViewById(R.id.dailybutton);
        final Button hourlybutton = findViewById(R.id.hourlybutton);
        final ImageView image1= findViewById(R.id.image1);
        final ImageView image2= findViewById(R.id.image2);
        final ImageView image3= findViewById(R.id.image3);
        final ImageView image4= findViewById(R.id.image4);
        final ImageView image5= findViewById(R.id.image5);
        final ImageView image6= findViewById(R.id.image6);
        final ImageView image7= findViewById(R.id.image7);

        //back
        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listView.setVisibility(View.GONE);
                dailybutton.setVisibility(View.VISIBLE);
                hourlybutton.setVisibility(View.VISIBLE);
                backbutton.setVisibility(View.GONE);
                listView2.setVisibility(View.GONE);
                image1.setVisibility(View.GONE);
                image2.setVisibility(View.GONE);
                image3.setVisibility(View.GONE);
                image4.setVisibility(View.GONE);
                image5.setVisibility(View.GONE);
                image6.setVisibility(View.GONE);
                image7.setVisibility(View.GONE);
                time_visible();
            }
        });

        //daily
        dailybutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listView.setVisibility(View.VISIBLE);
                dailybutton.setVisibility(View.GONE);
                hourlybutton.setVisibility(View.GONE);
                backbutton.setVisibility(View.VISIBLE);
                timer.setVisibility(View.GONE);
                today.setVisibility(View.GONE);
                image1.setVisibility(View.VISIBLE);
                image2.setVisibility(View.VISIBLE);
                image3.setVisibility(View.VISIBLE);
                image4.setVisibility(View.VISIBLE);
                image5.setVisibility(View.VISIBLE);
                image6.setVisibility(View.VISIBLE);
                image7.setVisibility(View.VISIBLE);
            }
        });

        //hourly
        hourlybutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listView2.setVisibility(View.VISIBLE);
                dailybutton.setVisibility(View.GONE);
                hourlybutton.setVisibility(View.GONE);
                backbutton.setVisibility(View.VISIBLE);
                timer.setVisibility(View.GONE);
                today.setVisibility(View.GONE);
            }
        });
    }
}

