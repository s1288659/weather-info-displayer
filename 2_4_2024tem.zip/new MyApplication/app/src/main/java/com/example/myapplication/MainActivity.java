package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;

import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;


public class MainActivity extends AppCompatActivity {
    private String TAG = "MainActivity";
    private ListView listView;
    private ListView listView2;

    void time_visible() {
        DateTimeFormatter dtf= DateTimeFormatter.ofPattern("yyyy/MM/dd");
        LocalDateTime now= LocalDateTime.now();
        TextView today = (TextView) findViewById(R.id.todate);
        today.setText(dtf.format(now));
        TextView timer = (TextView) findViewById(R.id.timer);
        int hr = new Date().getHours();
        int mn = new Date().getMinutes();
        String minutes;
        String hours;
        String tim = "";
        if (mn<10) {
            minutes = "0"+mn;
        } else {
            minutes = "" + mn;
        }
        if (hr<10) {
            hours = "0"+hr;
        } else {
            hours = ""+hr;
        }
        tim = hours + ":" + minutes;
        timer.setText(tim);
        timer.setVisibility(View.VISIBLE);
        today.setVisibility(View.VISIBLE);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        TextView timer = (TextView) findViewById(R.id.timer);
        TextView today = (TextView) findViewById(R.id.todate);
        time_visible();
        listView2 = (ListView) findViewById(R.id.listview2);
        JsonHandlerThread jsonHandlerThread2 = new JsonHandlerThread();
        jsonHandlerThread2.start();
        try {
            jsonHandlerThread2.join();
            SimpleAdapter adapter2 = new SimpleAdapter(
                    this,
                    TemperatureInfo.hourlytemperatureList,
                    R.layout.list_view_layout2,
                    new String[]{TemperatureInfo.HT, TemperatureInfo.HTEM},
                    new int[]{R.id.hourly_time, R.id.hourly_tem}
            );
            listView2.setAdapter(adapter2);
            listView2.setOnItemClickListener(
                    new AdapterView.OnItemClickListener() {
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            HashMap<String, String> temperature = TemperatureInfo.hourlytemperatureList.get(position);
                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                            builder.setTitle(temperature.get(TemperatureInfo.HT));
                            builder.setMessage("Temperature" + temperature.get(TemperatureInfo.HTEM));
                            AlertDialog alertDialog = builder.create();
                            alertDialog.show();
                        }
                    }
            );
        } catch (InterruptedException e) {
            Log.e(TAG, "InterruptedException:" + e.getMessage());
        }
        listView = (ListView) findViewById(R.id.listview);
        JsonHandlerThread jsonHandlerThread = new JsonHandlerThread();
        jsonHandlerThread.start();
        try {
            jsonHandlerThread.join();
            SimpleAdapter adapter = new SimpleAdapter(
                    this,
                    TemperatureInfo.temperatureList,
                    R.layout.list_view_layout,
                    new String[]{TemperatureInfo.DTIME,TemperatureInfo.DMAX, TemperatureInfo.DMIN},
                    new int[]{R.id.daily_time, R.id.daily_max, R.id.daily_min}
            );
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(
                    new AdapterView.OnItemClickListener() {
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            HashMap<String, String> temperature = TemperatureInfo.temperatureList.get(position);
                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                            builder.setTitle(temperature.get(TemperatureInfo.DMAX));
                            builder.setMessage("Temperature" + temperature.get(TemperatureInfo.DMIN));
                            AlertDialog alertDialog = builder.create();
                            alertDialog.show();
                        }
                    }
            );
        } catch (InterruptedException e) {
            Log.e(TAG, "InterruptedException:" + e.getMessage());
        }



        final Button backbutton = findViewById(R.id.backbutton);
        final Button dailybutton = findViewById(R.id.dailybutton);
        final Button hourlybutton = findViewById(R.id.hourlybutton);

        //back
        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listView.setVisibility(View.GONE);
                dailybutton.setVisibility(View.VISIBLE);
                hourlybutton.setVisibility(View.VISIBLE);
                backbutton.setVisibility(View.GONE);
                listView2.setVisibility(View.GONE);
                time_visible();
            }
        });

        //daily
        dailybutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listView.setVisibility(View.VISIBLE);
                dailybutton.setVisibility(View.GONE);
                hourlybutton.setVisibility(View.GONE);
                backbutton.setVisibility(View.VISIBLE);
                timer.setVisibility(View.GONE);
                today.setVisibility(View.GONE);
            }
        });

        //hourly
        hourlybutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listView2.setVisibility(View.VISIBLE);
                dailybutton.setVisibility(View.GONE);
                hourlybutton.setVisibility(View.GONE);
                backbutton.setVisibility(View.VISIBLE);
                timer.setVisibility(View.GONE);
                today.setVisibility(View.GONE);
            }
        });


    }
}

